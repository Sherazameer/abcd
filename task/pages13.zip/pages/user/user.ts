export class User {
  user_id: number;
  role_id: number;
  permission_id: number;
  username: string;
  password: any;
  first_name: string;
  last_name: string;
  phone: number;
  email: string;
  address: string;
  company: string;
  country_id: number;
  timezone_id: number;
  active: number;
  confirmPassword: any;
}
