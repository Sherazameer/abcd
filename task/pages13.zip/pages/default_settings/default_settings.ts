export class Settings {
  caller_id: string;
}
