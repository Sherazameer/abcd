export class coverpage {
    coverpage_id : number;
    title : string ;
    description : string ;
    created_by : any;
    tenant_id : any;
    defaultcover :any = false;
}