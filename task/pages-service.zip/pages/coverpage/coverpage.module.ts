import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoverpageRoutingModule } from './coverpage-routing.module';
import { routedComponents } from './coverpage-routing.module';



import { ThemeModule } from '../../@theme/theme.module';
import { MatTableModule } from '@angular/material/table';
import { CdkTableModule } from '@angular/cdk/table';
import { MatSortModule  } from '@angular/material/sort';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginatorModule } from '@angular/material/paginator';
import { FileUploadModule } from 'ng2-file-upload';
import { NbButtonModule, NbCardModule, NbIconModule, NbInputModule, NbTreeGridModule } from '@nebular/theme';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { Ng2CompleterModule } from 'ng2-completer';


@NgModule({

  imports: [
    CommonModule,
    CoverpageRoutingModule,
    ThemeModule,
    MatTableModule,
    CdkTableModule,
    MatSortModule,
    FileUploadModule,
    FormsModule,
    MatButtonModule,
    MatPaginatorModule,
    MatIconModule,
    NbCardModule,
    FormsModule,
    ReactiveFormsModule,
    NbIconModule,
    TranslateModule,
    Ng2CompleterModule,
    NbButtonModule,
    NbInputModule,
    NbTreeGridModule
  ],
  declarations: [
    ...routedComponents,
  ]
})
export class CoverpageModule { }
