import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-coverpage',
  templateUrl: './coverpage.component.html',
  styleUrls: ['./coverpage.component.scss']
})
export class CoverpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
