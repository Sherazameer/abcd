import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute, Params, ParamMap } from '@angular/router';
import { AppService } from '../../app.service';
import { Http, HttpModule, Response } from '@angular/http';
import { coverpage } from './coverpage';
import { CoverpageService } from './coverpage-service.service';
import { FormsModule } from '@angular/forms';
import 'rxjs/add/operator/toPromise';


@Component({
  selector: 'ngx-coverpage-form-component',
  templateUrl: './coverpage-form-component.html',
  styleUrls: ['./coverpage-form-component.component.scss']
})
export class AddCoverpageComponent implements OnInit {

  constructor(private http: Http, private route: ActivatedRoute, private coverpage_service: CoverpageService, private app_service: AppService, private router: Router) { }
   
  cover : coverpage = new coverpage;
  userid = localStorage.getItem('aid');
  tenant_id = localStorage.getItem('tid');
  coverpage_id: any= null;
  isError = false;
  errorText: any = [];
  

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.coverpage_id = +params['id'];
      const test_url = this.router.url.split('/');
      const lastsegment = test_url[test_url.length - 1];
      if (lastsegment === 'new') {
        return null;
      } else {
        return this.coverpage_service.get_Coverpage(this.coverpage_id).then(data => {
          this.cover = data;
          console.log(data);
        });
      }
    });
  
  }
  addcoverpage(){
   this.cover.created_by = this.userid;
   this.cover.tenant_id = this.tenant_id;
   console.log("THIS IS USERID", this.cover.created_by);
    this.checkFields();
      this.coverpage_service.add_Coverpage(this.cover).then(response => {
        this.router.navigate(['../../coverpage'], {relativeTo: this.route});
        });
      }
  updateCoverpage(): void {
    this.cover.created_by = this.userid;
    this.cover.tenant_id = this.tenant_id;
        this.checkFields();
        if (this.errorText.length === 0) {
          this.coverpage_service.Update_Coverpage(this.cover).then(() => {
            this.router.navigate(['../../coverpage'], {relativeTo: this.route});
          });
        }else{
          this.errorHandler(true, this.errorText);
        }
      }
      private checkFields(status = null):any{
        this.errorHandler(false, [])
        if (!this.cover.title) this.errorText.push("Title is required.");
      }
    
      private errorHandler(status, message):any{
        this.isError = status;
        this.errorText = message;
        if (status) {
          setTimeout(() => {
            this.isError = false;
            this.errorText = [];
          }, 10000);
        }
      }
    }
  


