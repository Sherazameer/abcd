import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoverpageComponentComponent } from './coverpage-component.component';

describe('CoverpageComponentComponent', () => {
  let component: CoverpageComponentComponent;
  let fixture: ComponentFixture<CoverpageComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoverpageComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CoverpageComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
