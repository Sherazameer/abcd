import { MenuItem } from './menu-item';

export const MENU_ITEMS: MenuItem[] = [
  {
    title: 'Dashboard',
    link: '/pages/dashboard',
    icon: 'home-outline',
    home: true,
    key: 'dashboard'
  },
  {
    title: 'Fax Campaigns',
    link: '/pages/campaigns/campaigns',
    icon: 'radio-outline',
    key: 'campaigns'
  },
  {
    title: 'Send Fax',
    icon: 'arrow-upward-outline',
    link: '/pages/sendfax/sendfax',
    key: 'send_fax'
  },
  {
    title: 'Receive Fax',
    icon: 'arrow-downward-outline',
    link: '/pages/infax',
    key: 'receive_fax'
  },
  {
    title: 'Contacts',
    icon: 'person-outline',
    key: 'contacts',
    children: [
      {
        title: 'Contacts',
        link: '/pages/contact/contacts',
        icon: 'person-add-outline',
        key: 'contacts',
      },
      {
        title: 'Groups',
        link: '/pages/contact/group',
        icon: 'people-outline',
        key: 'groups',
      },
    ],
  },
  {
    title: 'Fax Documents',
    link: '/pages/message/document',
    icon: 'file-text-outline',
    key: 'resources.fax_documents',
  },
  {
    title: 'My DIDs',
    link: '/pages/incoming_number/incoming_number',
    icon: 'arrow-downward-outline',
    key: 'my_dids'
  },
  {
    title: 'Administration',
    icon: 'settings-2-outline',
    key: 'administration',
    children: [
      {
        title: 'Branding',
        link: '/pages/branding',
        icon: 'tv-outline',
        key: 'branding'
      },
      {
        title: 'DID Numbers',
        link: '/pages/did/did',
        icon: 'smartphone-outline',
        key: 'did_number'
      },
      {
        title: 'Provider / Trunks',
        link: '/pages/provider/provider',
        icon: 'done-all-outline',
        key: 'providers'
      },
      {
        title: 'Tenants',
        link: '/pages/tenant/tenant',
        icon: 'people-outline',
        key: 'tenants'
      },
      {
        title: 'User Management',
        link: '/pages/user/user',
        icon: 'person-done-outline',
        key: 'user'
      },
      {
        title: 'Extensions',
        link: '/pages/extension/extension',
        icon: 'hash-outline',
        key: 'extensions'
      },
       {
        title: 'Cover Page',
        link: '/pages/coverpage/coverpage',
        icon: 'book-outline',
        key: 'cover_page'
      },
      {
        title: 'Fax Settings',
        link: '/pages/faxsettings',
        icon: 'file-text-outline',
        key: 'fax_setting'
      }
   ],
  },
  {
    title: 'CDR Reports',
    link: '/pages/cdr',
    icon: 'file-text-outline',
    key: 'cdr_reports'
  },
  /*
  {
    title: 'Billing',
    icon: 'settings-2-outline',
    children: [
      {
        title: 'Rates',
        link: '/pages/rate/rate',
        icon: 'file-text-outline'
      },
      {
        title: 'Rate Plans',
        link: '/pages/plan/plan',
        icon: 'book-outline'
      },
      {
        title: 'Payments',
        link: '/pages/payment/payment',
        icon: 'credit-card-outline'
      },
      {
        title: 'Routes',
        link: '/pages/route/route',
        icon: 'activity-outline'
      }
    ]
  },
*/
];

export const tenantMenuItems: MenuItem[] = [
  {
    title: 'Dashboard',
    link: '/pages/dashboard',
    icon: 'home-outline',
    home: true,
    key: 'dashboard'
  },
  {
    title: 'Fax Campaigns',
    link: '/pages/campaigns/campaigns',
    icon: 'radio-outline',
    key: 'campaigns'
  },
  {
    title: 'Send Fax',
    icon: 'arrow-upward-outline',
    link: '/pages/sendfax/sendfax',
    key: 'send_fax'
  },
  {
    title: 'Receive Fax',
    icon: 'arrow-downward-outline',
    link: '/pages/infax',
    key: 'receive_fax'
  },
  {
    title: 'Contacts',
    icon: 'person-outline',
    key: 'contacts',
    children: [
      {
        title: 'Contacts',
        link: '/pages/contact/contacts',
        icon: 'person-add-outline',
        key: 'contacts',
      },
      {
        title: 'Groups',
        link: '/pages/contact/group',
        icon: 'people-outline',
        key: 'groups',
      },
    ],
  },
  {
    title: 'Fax Documents',
    link: '/pages/message/document',
    icon: 'file-text-outline',
    key: 'resources.fax_documents',
  },
  {
    title: 'My DIDs',
    link: '/pages/incoming_number/incoming_number',
    icon: 'arrow-downward-outline',
    key: 'my_dids'
  },
  {
    title: 'Administration',
    icon: 'settings-2-outline',
    key: 'administration',
    children: [
      {
        title: 'Branding',
        link: '/pages/branding',
        icon: 'tv-outline',
        key: 'branding'
      },
      {
        title: 'User Management',
        link: '/pages/user/user',
        icon: 'person-done-outline',
        key: 'user'
      },
      {
        title: 'Fax Settings',
        link: '/pages/faxsettings',
        icon: 'file-text-outline',
        key: 'fax_setting'
      },
      {
        title: 'Cover Page',
        link: '/pages/coverpage/coverpage',
        icon: 'book-outline',
        key: 'cover_page'
      },
   ],
  },
  {
    title: 'CDR Reports',
    link: '/pages/cdr',
    icon: 'file-text-outline',
    key: 'cdr_reports'
  }
];

export const userMenuItems: MenuItem[] = [
  {
    title: 'Dashboard',
    icon: 'home-outline',
    link: '/pages/dashboard',
    home: true,
    key: 'dashboard'
  },
  {
    title: 'Fax Campaigns',
    link: '/pages/campaigns/campaigns',
    icon: 'radio-outline',
    key: 'campaigns'
  },
  {
    title: 'Send Fax',
    icon: 'arrow-upward-outline',
    link: '/pages/sendfax/sendfax',
    key: 'send_fax'
  },
  {
    title: 'Receive Fax',
    icon: 'arrow-downward-outline',
    link: '/pages/infax',
    key: 'receive_fax'
  },
  {
    title: 'Contacts',
    icon: 'person-outline',
    key: 'contacts',
    children: [
      {
        title: 'Contacts',
        link: '/pages/contact/contacts',
        icon: 'person-add-outline',
        key: 'contacts',
      },
      {
        title: 'Groups',
        link: '/pages/contact/group',
        icon: 'people-outline',
        key: 'groups',
      },
    ],
  },
  {
    title: 'Fax Documents',
    link: '/pages/message/document',
    icon: 'file-text-outline',
    key: 'resources.fax_documents',
  },
  {
    title: 'Administration',
    icon: 'settings-2-outline',
    key: 'administration',
    children: [
   {
    title: 'Cover Page',
    link: '/pages/coverpage/coverpage',
    icon: 'book-outline',
    key: 'cover_page'
  },
   {
        title: 'Fax Settings',
        link: '/pages/faxsettings',
        icon: 'file-text-outline',
        key: 'fax_setting'
      },
    ]
  },
  {
    title: 'CDR Reports',
    link: '/pages/cdr',
    icon: 'file-text-outline',
    key: 'cdr_reports'
  }
];
