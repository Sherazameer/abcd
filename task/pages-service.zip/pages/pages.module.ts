import { NgModule } from '@angular/core';
import { NbAlertModule, NbMenuModule } from '@nebular/theme';

import { ThemeModule } from '../@theme/theme.module';
import { PagesComponent } from './pages.component';
import { DashboardModule } from './dashboard/dashboard.module';
import { PagesRoutingModule } from './pages-routing.module';
import { MiscellaneousModule } from './miscellaneous/miscellaneous.module';
import { InFaxModule } from './infax/infax.module';
import { ChangePasswordModule } from './changepassword/changepassword.module';
import { CDRModule } from './cdr/cdr.module';
import { CampaignCDRModule } from './campaign_cdr/campaign_cdr.module';
import { FaxSettingsModule } from './faxsettings/faxsettings.module';

import { TenantModule } from './tenant/tenant.module';
import { BrandingModule } from './branding/branding.module';


@NgModule({
  imports: [
    PagesRoutingModule,
    ThemeModule,
    NbMenuModule,
    NbAlertModule,
    DashboardModule,
    InFaxModule,
    ChangePasswordModule,
    CDRModule,
    MiscellaneousModule,
    CampaignCDRModule,
    FaxSettingsModule,
    TenantModule,
    BrandingModule
  ],
  declarations: [
    PagesComponent,
  ]
})
export class PagesModule {
}
