export class IncomingNumber {
  phone: number;
  username: string;
  first_name: any;
  last_name: any;
  service_name: any;
  account_id: any;
  extension_id: any;
  did_id: any;
  email:any;
  user_id: any;
}
