export class Route {
  name: string;
  service_flag: number;
  destination_id: any;
  provider_id: number;
  destination: string;
  provider: string;
  // disable: string = null;
}
