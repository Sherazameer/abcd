export class Plan {
  plan_id: number;
  name: string;
  description: string;
}
