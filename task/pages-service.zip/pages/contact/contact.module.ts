import { NgModule } from '@angular/core';
import { ThemeModule } from '../../@theme/theme.module';
import { ContactRoutingModule, routedComponents } from './contact-routing.module';
import { MatSortModule  } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { FileUploadModule } from 'ng2-file-upload';
import { NbAutocompleteModule, NbButton, NbButtonModule, NbCardModule, NbIconModule, NbInputModule, NbOptionModule, NbSelectModule, NbTreeGridModule } from '@nebular/theme';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { Ng2CompleterModule } from 'ng2-completer';
import { CommonModule } from '@angular/common';
import { NgxPaginationModule } from 'ngx-pagination';




@NgModule({
  imports: [
    ThemeModule,
    CommonModule,
    ContactRoutingModule,
    FileUploadModule,
    MatSortModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    NgxPaginationModule,
    NbIconModule,
    NbCardModule,
    FormsModule,
    ReactiveFormsModule,
    NbIconModule,
    NbButtonModule,
    TranslateModule,
    Ng2CompleterModule,
    NbInputModule,
    NbTreeGridModule,
    NbSelectModule,
    NbAutocompleteModule,
    NbOptionModule,
  ],
  declarations: [
    ...routedComponents,
  ],
})
export class ContactModule { }
