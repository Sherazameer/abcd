import { Component, OnInit, ElementRef, ViewChild, TemplateRef } from '@angular/core';
import { ContactService } from './contact.service';
// import { MatSort, Sort } from '@angular/material/sort';
// import { MatPaginator } from '@angular/material/paginator';
import { ContactDatabase } from './contact-database.component';
import { ContactDataSource } from './contact-datasource.component';
import { ModalComponent } from '../../modal.component';
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs/Rx';
import { SendFaxService } from '../sendfax/sendfax.service';
import { CompleterData, CompleterItem, CompleterService } from 'ng2-completer';
import { Contact } from './contact';
import { DID } from '../did/did';
import { DocumentProgram, SendFax } from '../sendfax/sendfax';
import { AppService } from '../../app.service';
import { FileUploader, FileUploaderOptions } from 'ng2-file-upload';
import { ActivatedRoute, Router } from '@angular/router';
import { Document } from '../message/document/document';
import { DocumentService } from '../message/document/document.service';
import { NbWindowRef, NbWindowService } from '@nebular/theme';
import { TranslateService } from '@ngx-translate/core';
import { fromEvent } from 'rxjs';
import { NbSortDirection, NbSortRequest, NbTreeGridDataSource, NbTreeGridDataSourceBuilder } from '@nebular/theme';

@Component({
  selector: 'ngx-contact-component',
  templateUrl: './contact-component.html',
  styleUrls: ['./contact-component.scss'],
})


export class FormsContactComponent implements OnInit {
  constructor(
    private contact_service: ContactService,
    private dataSourceBuilder: NbTreeGridDataSourceBuilder<Contact>,
    private modalService: NgbModal,
    private sendfax_service: SendFaxService,
    private completerService: CompleterService,
    private app_service: AppService, private router: Router,
    private route: ActivatedRoute, private document_service: DocumentService,
    private windowService: NbWindowService,
    private translateService: TranslateService,
  ) { }


  itemsPerPage: number = 10;
  currentPage: number = 1;
  totalItems: number;
  length: number;

  // aContact: dataSource | null;
  aContact: Contact[];
  ContactDataSource: NbTreeGridDataSource<Contact>;
  closeResult: any;
  contactArray: Contact[] = [];
  accountArray: DID[] = [];
  trans_id: any;
  sendfax: SendFax = new SendFax;
  documentProgram: DocumentProgram = new DocumentProgram;
  dataService: CompleterData;
  documentArray: Document[] = [];
  document: Document = new Document;


  public file_sending = false;
  public file_sent = false;
  private windowRef: NbWindowRef;
  private modalRef: NgbModalRef;



    file: any = [];
    document_id: any = [];
    URL = `${this.app_service.apiUrlDocument}/${this.document_id}/media`;
    public uploader: FileUploader = new FileUploader({ url: this.URL, disableMultipart: true });
    unsupportedErr: boolean = false;
    isError = false;
    errorText: any = [];

    sortColumn: string;
    sortDirection: NbSortDirection = NbSortDirection.NONE;

      displayedColumns = ['ID', 'first_name', 'last_name', 'phone', 'email', 'Operations'];

    // @ViewChild(MatSort) sort: MatSort;
    // @ViewChild(MatPaginator) paginator: MatPaginator;

    @ViewChild('filter') filter: ElementRef;
    @ViewChild('deleteTemplate', { static: true }) deleteTemplate: TemplateRef<any>;

  ngOnInit() {
    this.getContactlist();
    this.getAccountlist();
    this.getdestination();
    this.getDocumentlist();

    this.document.quality = 'standard';

    this.itemsPerPage = 5;
    this.currentPage = 1;
    this.totalItems = 0;

    this.uploader.onBeforeUploadItem = (item) => {
      item.method = 'POST';
      item.url = this.URL;
      item.withCredentials = false;
    };
    this.uploader.onAfterAddingFile = (response: any) => {
      console.log(response);
      this.file = response;
      if (response.file.type == 'application/pdf' || response.file.type == 'image/png' || response.file.type == 'image/jpg' || response.file.type == 'image/jpeg' || response.file.type == 'image/tiff' || response.file.type == 'image/tif' || response.file.type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || response.file.type == 'application/msword' || response.file.type == 'application/vnd.openxmlformats-officedocument.presentationml.presentation' || response.file.type == 'application/vnd.ms-powerpoint' || response.file.type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || response.file.type == 'application/vnd.ms-excel' || response.file.type == 'application/vnd.oasis.opendocument.text' || response.file.type == 'application/vnd.oasis.opendocument.presentation' || response.file.type == 'application/vnd.oasis.opendocument.spreadsheet') {
      }
      else {
        this.unsupportedErr = true;
        this.uploader.removeFromQueue(response);
        setTimeout(() => {
          this.unsupportedErr = false;
        }, 2000);
      }
    };

    const authHeader = this.app_service.upload_Header;
    const uploadOptions = <FileUploaderOptions>{ headers: authHeader };
    this.uploader.setOptions(uploadOptions);

    this.uploader.onSuccessItem = (item: any, response: any, status: any, headers: any) => {
    };
  }

  pageChanged(event: any): void {
    this.currentPage = event.page;
  }



  getContactlist() {
    this.contact_service.get_ContactList().then(data => {
      this.aContact = data as Contact[];
      this.length = data.length;

      this.ContactDataSource = this.dataSourceBuilder.create(data.map(item => ({ data: item })),);
      console.log('check data', data)
        // { sort: this.sort, paginator: this.paginator } error

    });
  }


  updateSort(event: NbSortRequest): void {
    this.sortColumn = event.column;
    this.sortDirection = event.direction;
    // Add your logic to apply sorting based on the sort column and direction
    // Example: Call a method to fetch sorted data from the service
    // this.fetchSortedData(event.column, event.direction);
  }


  deleteContact(contact_id): void {
    this.contact_service.delete_Contact(contact_id)
      .then(response => {
      })
      .catch(this.handleError);
    this.getContactlist();
    this.onSave();
  }

  showStaticModal(contact_id, first_name) {
    this.translateService.get('transmission.head').subscribe((translatedTitle: string) => {
      this.windowRef = this.windowService.open(this.deleteTemplate, { title: translatedTitle, context: { first_name: first_name, contact_id: contact_id } });
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  //When we click on sendfax button in operation column....!
  getAccountlist() {
    this.sendfax_service.get_AccountList().then(data => {
      this.accountArray = data;
      this.sendfax.account_id = this.accountArray[this.accountArray.length - 1].account_id;

    })
  }

  onSelectAccount(value) {
    if (value != 0) {
      this.sendfax.account_id = value;
    }
    else {
      this.sendfax.account_id = undefined;
    }
  }

  open(content,contact_id) {
    this.sendfax.contact_id = contact_id;
    this.translateService.get('contact.contact_form.title').subscribe((translatedTitle: string) => {
      this.windowRef = this.windowService.open(content, { title: translatedTitle });
    });
  }

  onSave() {
  this.windowRef.close();
  }

  getdestination() {
    this.contact_service.get_ContactList().then(data => {
      this.contactArray = data;
      this.dataService = this.completerService.local(this.contactArray, 'phone', 'phone');
    })
  }

  onSelected(item: CompleterItem) {
    if (item != null) {
      this.sendfax.contact_id = item.originalObject.contact_id;
    }
    else {
      this.sendfax.contact_id = undefined;
    }
  }

  // sending fax to outbound
  addSendDocument(): void {
    if (this.sendfax.contact_id != undefined) {
      this.sendfax.phone = undefined;
    }
    this.sendfax_service.add_senddocument(this.documentProgram).then(response => {
      const program_id = response;
      this.sendfax.program_id = program_id;
      this.AddTransmission();
      this.onSave();
    });
  }

  AddTransmission(): void {
    this.sendfax_service.add_SendFax(this.sendfax).then(response => {
      const transmission_id = response;
      this.trans_id = transmission_id;
      this.AddSend(this.trans_id);
    });
  }

  AddSend(trans_id): void {
    this.sendfax_service.send_transmission(this.trans_id).then(response => {
    });
  }

  getDocumentlist() {
    this.document_service.get_DocumentList().then(data => {
      this.documentArray = data;
      if (data) this.documentProgram.document_id = this.documentArray[this.documentArray.length -1].document_id;
    });
  }

  onSelect(value) {
    if (value != 0) {
      this.documentProgram.document_id = value;
    }
    else {
      this.documentProgram.document_id = undefined;
    }
    console.log(this.documentProgram.document_id);
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }

}
