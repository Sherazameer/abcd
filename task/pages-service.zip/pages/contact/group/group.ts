export class Group {
  group_id: number;
  name: string;
  description: string;
  contact_total: number;
}

