import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TenantComponent } from './tenant.component';
import { FormsTenantComponent } from './tenant-component';
import { AddTenantComponent } from './tenant-form-component';

const routes: Routes = [{
  path: '',
  component: TenantComponent,
  children: [{
    path: 'tenant',
    component: FormsTenantComponent,
  }, {
    path: 'tenant/new',
    component: AddTenantComponent,
  }, {
    path: 'tenant/:id',
    component: AddTenantComponent,
  }, {
    path: 'tenant/:id/delete',
    component: AddTenantComponent,
  }],
}];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
  ],
  exports: [
    RouterModule,
  ],
})
export class TenantRoutingModule {

}

export const routedComponents = [
  TenantComponent,
  FormsTenantComponent,
  AddTenantComponent,
];
