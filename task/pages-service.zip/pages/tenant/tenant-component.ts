import { Component, OnInit, ViewChild, ElementRef, TemplateRef } from '@angular/core';
import { TenantService } from './tenant.service';
import { MatSort, Sort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { NbAuthService, NbAuthJWTToken } from '@nebular/auth';
import { TenantDatabase } from './tenant-database.component';
import { TenantDataSource } from './tenant-datasource.component';
import { ModalComponent } from '../../modal.component';
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { fromEvent } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Router } from '@angular/router';
import { NbWindowService } from '@nebular/theme';
import { TranslateService } from '@ngx-translate/core';
import { NbWindowRef } from '@nebular/theme';
import { NbTreeGridDataSource, NbTreeGridDataSourceBuilder } from '@nebular/theme';
import { Tenant } from './tenant';



@Component({
  selector: 'ngx-tenant-component',
  templateUrl: './tenant-component.html',
  styleUrls: ['./tenant-component.scss'],
})

export class FormsTenantComponent implements OnInit {

  // aTenant: TenantDataSource | null;
  aTenant: Tenant[];

  TenantDataSource: NbTreeGridDataSource<Tenant>;

  length: number;
  closeResult: any;
  auser: any;
  private windowRef: NbWindowRef;
  private modalRef: NgbModalRef;

  displayedColumns= ['ID', 'company', 'first_name', 'last_name', 'email', 'Operations'];
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  @ViewChild('filter', {static: false}) filter: ElementRef;
  @ViewChild('deleteTemplate', { static: true }) deleteTemplate: TemplateRef<any>;


  constructor(private tenant_service: TenantService,
  private dataSourceBuilder: NbTreeGridDataSourceBuilder<Tenant>,
  private modalService: NgbModal,
  private authService: NbAuthService,
  private windowService : NbWindowService,
  private translateService : TranslateService,
  private router: Router) {

      this.authService.onTokenChange()
      .subscribe((token: NbAuthJWTToken,
      ) => {
        if (token && token.getValue()) {
          this.auser = token.getPayload();
        }
      });

    }

  ngOnInit(): void {
    this.getTenantlist();
  }

  getTenantlist() {
    this.tenant_service.get_TenantList().then(data => {
      this.aTenant = data as Tenant[];
      this.length = data.length;

      this.TenantDataSource = this.dataSourceBuilder.create(
        this.aTenant.map(item => ({ data: item })),);
      // this.aTenant = new TenantDataSource(new TenantDatabase( data ), this.sort, this.paginator);

      //Sort the data automatically
      const sortState: Sort = {active: 'ID', direction: 'desc'};
      this.sort.active = sortState.active;
      this.sort.direction = sortState.direction;
      this.sort.sortChange.emit(sortState);

      // Observable for the filter
      fromEvent(this.filter.nativeElement, 'keyup')
      .pipe(debounceTime(150),
      distinctUntilChanged())
     .subscribe(() => {
       if (!this.aTenant) { return; }
       this.aTenant.filter = this.filter.nativeElement.value;
      });
    });
  }

  deleteTenant(tenant_id): void {
    this.tenant_service.delete_Tenant(tenant_id)
    .then(response => {
    })
    .catch(this.handleError);
    this.getTenantlist();
    this.closeModal();
  }

  // Modal related
  showStaticModal(tenant_id, first_name) {
    this.translateService.get('transmission.head').subscribe((translatedTitle: string) => {
      this.windowRef = this.windowService.open(this.deleteTemplate, { title: translatedTitle, context: { first_name: first_name, tenant_id: tenant_id } });
    });
  }
  closeModal() {
    this.windowRef.close();
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }

}
