import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { User } from './user';
import { AUserService } from './user.service';
import 'rxjs/add/operator/toPromise';
import { exit } from 'process';

@Component({
  selector: 'ngx-add-user-component',
  templateUrl: './user-form-component.html',
  styleUrls: ['./user-form-component.scss'],
})

export class AddUserComponent implements OnInit {

  constructor(private route: ActivatedRoute, private user_service: AUserService,
  private router: Router) { }

  // form1: any= {};
  user: User= new User;
  tenant: any;
  user_id: any = null;
  is_admin: any = 0;
  form: FormGroup;
  role: any;
  permissions: any;
  user_permission: any = [];
  tenants: any;
  timezones: any;
  toppings = new FormControl();

  isError = false;
  errorText: any = [];
  // isSuccess = false;
  // successText = null;
  remain_daily: any = 0;
  remain_monthly: any = 0;

  ngOnInit(): void {

    this.user["tenant_id"] = Number(localStorage.getItem('tid'));
    this.is_admin = Number(localStorage.getItem('is_admin'));
    if (this.is_admin == 1) this.getAllTenants();
    else this.getTenant(this.user.tenant_id);
    
    // Setting up role for tenant
    (Number(localStorage.getItem('is_tenant')) == 1) ? this.getAllRoles(1) : this.getAllRoles();
    // Get Timezone
    this.getTinezone();

    this.route.params.subscribe(params => {
      this.user_id = +params['id'];
      const test_url = this.router.url.split('/');
      const lastsegment = test_url[test_url.length - 1];
      if (lastsegment === 'new') {
        return null;
      } else {
        return this.user_service.get_UserData(this.user_id).then(data => {
          this.user = data;
          this.getUserRoles(this.user.user_id);
          setTimeout(() => {
            this.updateTenantLimit(this.user.tenant_id);
          }, 2000);
        });
      }
    }); 
  }

  getAllRoles(id = null) {
    this.user_service.get_RoleList().then(response => {
      this.role = response;
      this.role.forEach(element => {
        if (id == element.role_id) element.state = true;
        else element.state = null;
      });
    })
  }

  getAllTenants() {
    this.user_service.get_TenantList().then(response => {
      this.tenants = response;
      console.log(response);
      this.tenants.forEach(element => {
        element.state = null;
      });
    })
  }

  getTenant(tenant_id) {
    this.user_service.get_TenantData(tenant_id).then(response => {
      this.remain_daily = response.daily_limit - response.assigned_daily;
      this.remain_monthly = response.monthly_limit - response.assigned_monthly;
      return response;
    });
  }

  updateTenantLimit(tenant_id) {
    if (this.tenants) {
      const tenantIndex = this.tenants.findIndex(obj => obj.tenant_id === tenant_id);
      if (tenantIndex !== -1) {
        this.tenants[tenantIndex].assigned_daily = this.tenants[tenantIndex].assigned_daily - this.user.daily_limit;
        this.tenants[tenantIndex].assigned_monthly = this.tenants[tenantIndex].assigned_monthly - this.user.monthly_limit;
        this.remain_daily = this.tenants[tenantIndex].daily_limit - this.tenants[tenantIndex].assigned_daily;
        this.remain_monthly = this.tenants[tenantIndex].monthly_limit - this.tenants[tenantIndex].assigned_monthly;
      }
    } else {
      this.remain_daily = parseInt(this.remain_daily) + parseInt(this.user.daily_limit);
      this.remain_monthly = parseInt(this.remain_monthly) + parseInt(this.user.monthly_limit);
    } 
  }

  getUserRoles(user_id) {
    this.user_service.getUserRoles(user_id).then(response => {
      if (response.length != 0) {
        response.forEach(element => {
          this.role.forEach(roles => {
            if (element.role_id == roles.role_id) {
              roles.state = true;
            }
          });
        });
      }
    })    
  }

  getTinezone() {
    this.user_service.get_Timezone().then(response => {
      this.timezones = response;
    })
  }

  addUser(): void {
    this.checkFields("new");
    if (this.errorText.length === 0) {      
      this.user.user_permission = this.user_permission ? this.user_permission.toString() : "null";
      this.user_service.add_User(this.user).then(response => {      
        this.setRoles(response);
        this.router.navigate(['../../user'], {relativeTo: this.route});
      });
    }else{
      this.errorHandler(true, this.errorText);
    }
  }

  updateUser(): void {
    this.checkFields();
    if (this.errorText.length === 0) {
      this.user.user_permission = this.user_permission ? this.user_permission.toString() : "null";
      this.user_service.update_User(this.user).then(() => {
        this.setRoles(this.user.user_id);
        this.router.navigate(['../../user'], {relativeTo: this.route});
      });
    }else{
      this.errorHandler(true, this.errorText);
    }
  }

  addRoles(user_id, role_id) {
    this.user_service.setRole(user_id, role_id).then(response => {
    })
  }

  setRoles(user_id) {
    this.role.forEach(element => {
      if (element.state == true) {
        this.addRoles(user_id, element.role_id);
      }
      else if (element.state == null || element.state == false) {
        this.deleteRoles(user_id, element.role_id);
      }
    })  
  }

  deleteRoles(user_id, role_id) {
    this.user_service.deleteRoles(user_id, role_id).then(response => {
    })
  }

  onChange(role_id, is_checked) {
    this.role.forEach(element => {
      if (role_id == element.role_id) {
        element.state = is_checked;
      }
    });    
  }

  onTenantChange(id) {
    this.tenants.forEach(tenant => {
      if (id == tenant.tenant_id) {
        this.remain_daily = tenant.daily_limit - tenant.assigned_daily;
        this.remain_monthly = tenant.monthly_limit - tenant.assigned_monthly;
      }
    });    
  }

  private checkFields(status = null):any{
    this.errorHandler(false, [])
    if (!this.user.first_name) this.errorText.push("First name is required.");
    if (status == "new") {
      if (!this.user.password || !this.user.confirmPassword) this.errorText.push("Password is required.");
      if (this.user.password!==this.user.confirmPassword) this.errorText.push("Confirm Password must match with Password.");
    }
    if (!this.user.username ) this.errorText.push("Username is required.");
    if (!this.user.email) this.errorText.push("Eamil address is required.");
    if (!this.user.phone) this.errorText.push("Caller ID is required.");
    if (!this.user.tenant_id) this.errorText.push("Please select Tenant.");
  }

  private errorHandler(status, message):any{
    this.isError = status;
    this.errorText = message;
    if (status) {
      setTimeout(() => {
        this.isError = false;
        this.errorText = [];
      }, 10000);
    }
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}