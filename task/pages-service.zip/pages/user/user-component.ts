import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AUserService } from './user.service';
import { MatSort,  Sort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { UserDatabase } from './user-database.component';
import { UserDataSource } from './user-datasource.component';
import { ModalComponent } from '../../modal.component';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { fromEvent } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { NbAuthService, NbAuthJWTToken } from '@nebular/auth';
import { Router } from '@angular/router';
import { NbWindowService,NbWindowRef} from '@nebular/theme';
import { TranslateService } from '@ngx-translate/core';
import { NbTreeGridDataSource, NbTreeGridDataSourceBuilder } from '@nebular/theme';
import { User } from './user';



@Component({
  selector: 'ngx-user-component',
  templateUrl: './user-component.html',
  styleUrls: ['./user-component.scss'],
})

export class FormsUserComponent implements OnInit {

  constructor(private user_service: AUserService,
  private dataSourceBuilder: NbTreeGridDataSourceBuilder<User>,
  private modalService: NgbModal,
  private authService: NbAuthService,
  private router: Router,
  private translateService: TranslateService,
  private windowService: NbWindowService
) {

    this.authService.onTokenChange()
    .subscribe((token: NbAuthJWTToken,
    ) => {
      if (token && token.getValue()) {
        this.auser = token.getPayload();
      }
    });

  }

  aUser: User[];
  UserDataSource: NbTreeGridDataSource<User>;

  length: number;
  closeResult: any;
  is_admin: any = 0;
  is_tenant: any = 0;

  private windowRef: NbWindowRef;


  displayedColumns= ['ID', 'company', 'first_name','email', 'user_role', 'Operations'];

  @ViewChild(MatSort) sort: MatSort;

  @ViewChild(MatPaginator) paginator: MatPaginator;

  @ViewChild('filter') filter: ElementRef;

  auser: any;

  ngOnInit() {
    this.is_admin = Number(localStorage.getItem('is_admin'));
    this.is_tenant = Number(localStorage.getItem('is_tenant'));
    if (this.is_admin == 1) this.getUserlist();
    else this.getUserlist(this.auser.tenant_id);
  }

  getUserlist(tenant_id = 0) {
    this.user_service.get_UserList(tenant_id).then(data => {
      this.aUser = data as User[];
      this.length = data.length;
      this.UserDataSource = this.dataSourceBuilder.create(this.aUser.map(item => ({ data: item })),);


      //Sort the data automatically

      const sortState: Sort = {active: 'ID', direction: 'desc'};
      this.sort.active = sortState.active;
      this.sort.direction = sortState.direction;
      this.sort.sortChange.emit(sortState);

      // Observable for the filter
      fromEvent(this.filter.nativeElement, 'keyup')
      .pipe(debounceTime(150),
      distinctUntilChanged())
     .subscribe(() => {
       if (!this.aUser) { return; }
       this.aUser.filter = this.filter.nativeElement.value;
      });
    });
  }

  deleteUser(user_id): void {
    this.user_service.delete_User(user_id)
    .then(response => {
    })
    .catch(this.handleError);
    this.getUserlist();
    this.onSave();
  }

  sign(user) {
    this.user_service.get_UserToken(user.user_id).then(resp => {
      let abc: any = resp;

      localStorage.removeItem('username');
      localStorage.removeItem('is_admin');
      localStorage.removeItem('is_tenant');
      localStorage.setItem('username', user.username);
      localStorage.setItem('is_admin', user.is_admin);
      localStorage.setItem('is_tenant', user.is_tenant);
      localStorage.setItem('permission', "");
      if (user.user_permission) localStorage.setItem('permission', user.user_permission);

      this.router.navigate(['/dashboard']);
      localStorage.setItem('copy_token', abc.token);

    })
    .catch(err => {
      console.log(err);
    })
  }

  // Modal related
  showStaticModal(deleteTemplate,first_name,user_id) {
    this.translateService.get('transmission.head').subscribe((translatedTitle: string) => {
      this.windowRef = this.windowService.open(deleteTemplate, { title: translatedTitle, context: { first_name : first_name,user_id: user_id } });
    });
  }

  onSave() {
    this.windowRef.close();
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }
  // open(content) {
  //   this.translateService.get('user.user_form.title').subscribe((translatedTitle: string) => {
  //     this.windowRef = this.windowService.open(content, { title: translatedTitle });
  //   });
  // }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}
