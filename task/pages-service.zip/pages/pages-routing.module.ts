import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';

import { PagesComponent } from './pages.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NotFoundComponent } from './miscellaneous/not-found/not-found.component';
import { InFaxComponent } from './infax/infax-component';
import { ChangePasswordComponent } from './changepassword/changepassword-component';
import { CDRComponent } from './cdr/cdr.component';
import { CampaignCDRComponent } from './campaign_cdr/campaign_cdr.component';
import { FaxSettingsComponent } from './faxsettings/faxsettings-component';
import { BrandingComponent } from './branding/branding-component';

const routes: Routes = [{
  path: '',
  component: PagesComponent,
  children: [
    {
      path: 'dashboard',
      component: DashboardComponent,
    },
    {
      path: 'infax',
      component: InFaxComponent
    },
    // {
    //   path: 'tenant',
    //   component: FormsTenantComponent
    // },
    {
      path: 'Changepass',
      component: ChangePasswordComponent
    },
    {
      path: 'cdr',
      component: CDRComponent,
    },
    {
      path: 'faxsettings',
      component: FaxSettingsComponent,
    },

    {
      path: 'campaigncdr',
      component: CampaignCDRComponent,
    },
    {
      path: 'branding',
      component: BrandingComponent,
    },
    {
      path: 'miscellaneous',
      loadChildren: () => import('./miscellaneous/miscellaneous.module')
        .then(m => m.MiscellaneousModule),
    },
    {
      path: 'contact',
      loadChildren: () => import('./contact/contact.module')
        .then(m => m.ContactModule),
    },
    {
      path: 'message',
      loadChildren: () => import('./message/message.module')
        .then(m => m.MessageModule),
    },
    {
      path: 'provider',
      loadChildren: () => import('./provider/provider.module')
        .then(m => m.ProviderModule),
    },
    {
      path: 'tenant',
      loadChildren: () => import('./tenant/tenant.module')
        .then(m => m.TenantModule),
    },
    {
      path: 'user',
      loadChildren: () => import('./user/user.module')
        .then(m => m.UserModule),
    },
    {
      path: 'extension',
      loadChildren: () => import('./extension/extension.module')
        .then(m => m.ExtensionModule),
    },
    {
      path: 'campaigns',
      loadChildren: () => import('./campaigns/campaign.module')
        .then(m => m.CampaignModule),
    },
    {
      path: 'campaigns',
      loadChildren: () => import('./campaigns/campaign.module')
        .then(m => m.CampaignModule),
    },
    {
      path: 'sendfax',
      loadChildren: () => import('./sendfax/sendfax.module')
        .then(m => m.SendFaxModule),
    },
    {
      path: 'did',
      loadChildren: () => import('./did/did.module')
        .then(m => m.DIDModule),
    },
    {
      path: 'incoming_number',
      loadChildren: () => import('./incoming_number/incoming_number.module')
        .then(m => m.IncomingNumberModule),
    },
    {
      path: 'rate',
      loadChildren: () => import('./rate/rate.module')
        .then(m => m.RateModule),
    },
    {
      path: 'plan',
      loadChildren: () => import('./plan/plan.module')
        .then(m => m.PlanModule),
    },
    {
      path: 'payment',
      loadChildren: () => import('./payment/payment.module')
        .then(m => m.PaymentModule),
    },
    {
      path: 'route',
      loadChildren: () => import('./route/route.module')
        .then(m => m.RouteModule),
    },
    {
      path: 'coverpage',
      loadChildren: () => import('./coverpage/coverpage.module')
        .then(m => m.CoverpageModule),
    },
    {
      path: '',
      redirectTo: 'dashboard',
      pathMatch: 'full',
    },
    {
      path: '**',
      component: NotFoundComponent,
    },
  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PagesRoutingModule {
}
