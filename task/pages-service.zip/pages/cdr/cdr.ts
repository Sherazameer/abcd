export class CDR {
  time_start: any;
  time_connect: any;
  time_end: any;
  amount: any;
  first_name: string;
  company: string;
  status: any;
  transmission_id: number;
  direction: string;
  contact_id: number;
  account_id: number;
  contact_phone: any;
  account_phone: any;
  pages:any;
  cost: any;
}