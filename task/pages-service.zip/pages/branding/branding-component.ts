import { Component, OnInit } from '@angular/core';
import { BrandingService } from './branding.service';
import { NbAuthService, NbAuthJWTToken } from '@nebular/auth';
import { AppService } from '../../app.service';
import { User } from '../user/user';
import { FileUploader, FileUploaderOptions } from 'ng2-file-upload';
import { Branding } from './branding';

@Component({
  selector: 'ngx-branding-component',
  templateUrl: './branding-component.html',
  styleUrls: ['./branding-component.scss'],
})

export class BrandingComponent implements OnInit {

  auser:any;
  user: User = new User;
  URL = `${this.app_service.apiUrlBranding}/${this.user.tenant_id}/media`;
  file: any;
  public uploader: FileUploader = new FileUploader({url: this.URL, disableMultipart: true });
  branding: Branding = new Branding;
  isAdmin_Checked = false; 
  is_admin: any = 0;

  image_error: any = '';
  is_error = false;

  constructor(private branding_service: BrandingService, private authService: NbAuthService, private app_service: AppService) {
    this.authService.onTokenChange()
    .subscribe((token: NbAuthJWTToken) => {
      if (token && token.getValue()) {
        this.auser = token.getPayload();
        this.user.tenant_id = this.auser.tenant_id;
        this.URL = `${this.app_service.apiUrlBranding}/${this.user.tenant_id}/media`;
        this.getSettings();
      }
    });
  }

  ngOnInit(): void {
    this.is_admin = Number(localStorage.getItem('is_admin'));
    this.uploader.onBeforeUploadItem = (item) => {
      item.method = 'PUT';
      item.url = this.URL;
      item.withCredentials = false;
    };

    this.uploader.onAfterAddingFile = (response: any) => {
      this.file = response;
    };

    const authHeader = this.app_service.upload_Header;
    const uploadOptions = <FileUploaderOptions>{headers : authHeader};
    this.uploader.setOptions(uploadOptions);

    this.uploader.onSuccessItem = (item: any, response: any, status: any, headers: any) => {
      if (status == 200) {
        this.branding.logo = response.replace(/\\/g, '');
        this.saveSettings();
      }
    };
  }

  getSettings() {
    this.branding_service.get_Branding(this.user.tenant_id).then(response => {
      this.branding.domain = response['domain'];
      this.branding.title = response['title'];
      this.branding.footer = response['footer'];
      this.branding.logo = response['logo'];
      if (response.defaultvalue = 1) {
        this.isAdmin_Checked = true;
      }
    });
  }

  onCheckboxChange(): void {
    if (this.isAdmin_Checked === true) {
      this.branding.defaultvalue = 1;
    } else {
      this.branding.defaultvalue = 0;
    }
  }

  async updateSettings() {
    if (this.file != null) await this.file;
    else this.saveSettings();
  }

  saveSettings(){
    this.branding_service.add_Branding(this.user.tenant_id, this.branding).then(response => {
      this.app_service.success_message = 'Saved Successfully';
      this.clearMsg();
      setTimeout(() => {
        window.location.reload();
      }, 500);
    }).catch(err => {
      this.app_service.errors = 'Error saving configuration';
      this.clearMsg();
    });
  }

  clearMsg() {
    setTimeout(() => {
      this.app_service.errors = '';
      this.app_service.success_message = '';
    }, 2000);
  }

  onFileChange(event) {
    let reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      let file = event.target.files[0];

      const img = new Image();
      var maxwidth = 400;
      var maxheight = 90;
      img.src = window.URL.createObjectURL( file );

      img.onload = () => { 
        var imgwidth = img.width;
        var imgheight = img.height;
        if(imgwidth <= maxwidth && imgheight <= maxheight) {


          alert(`it can be uploaded`);
          this.file.upload()
          } else {
          alert(`Sorry, this image doesn't look like the size we wanted.`);
          
        }
        // }else {
        //   this.is_error = true;
        //   this.image_error = "Maximum allowed image width is 400 and maximum allowed height is 90";
        //   this.removeError();
        //   event.srcElement.value = null;
        
      }
    }
  } 
  
}
