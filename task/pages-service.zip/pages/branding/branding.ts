export class Branding {
  tenant_id: number;
  domain: string;
  title: string;
  logo: string;
  footer: string;
  defaultvalue: number;
}