export class Payment {
  payment_id: number;
  name: any;
  description: string;
  type:string;
  paid_amount: number;
  paid_date: string;
  usr_id: number;
}
