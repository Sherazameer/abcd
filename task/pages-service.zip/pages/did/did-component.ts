import { map } from 'rxjs/operators';
import { Component, OnInit, ViewChild } from '@angular/core';
import { DIDService } from './did.service';
import { DID } from './did';
import { DataSource } from '@angular/cdk/collections';
import {  MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DIDDatabase } from './did-database.component';
import { DIDDataSource } from './did-datasource.component';
import { ModalComponent } from '../../modal.component';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { AUserService } from '../user/user.service';
import { User } from '../user/user';
import { NbWindowService } from '@nebular/theme';
import { TranslateService } from '@ngx-translate/core';
import { NbTreeGridDataSource, NbTreeGridDataSourceBuilder } from '@nebular/theme';
@Component({
  selector: 'ngx-did-component',
  templateUrl: './did-component.html',
  styleUrls: ['./did-component.scss'],
})


export class FormsDIDComponent implements OnInit {
  windowRef: import("@nebular/theme").NbWindowRef<any, any>;
  constructor(

  private did_service: DIDService,
  private dataSourceBuilder: NbTreeGridDataSourceBuilder<DID>,

  private modalService: NgbModal,
  private user_service: AUserService,
  private windowService : NbWindowService,
  private translateService : TranslateService
) { }

  // aDID: DIDDataSource | null;
  aDID: DID[];
  DIDDataSource: NbTreeGridDataSource<DID>;

  length: number;
  closeResult: any;
  data: [];
  users: User[] = [];

  displayedColumns= ['phone', 'first_name', 'assigned_to', 'Operations'];

  @ViewChild(MatSort) sort: MatSort;

  @ViewChild(MatPaginator) paginator: MatPaginator;




  ngOnInit() {
    this.getDIDlist();
  }

  getDIDlist() {
    this.did_service.get_DIDList().then(data => {
      this.aDID = data;
      // console.log('adid check data',this.aDID); // Add this line to check if data is being retrieved

      this.length = data.length;
      this.data = data;
      this.getUserlist();
    });
  }

  getUserlist() {
    this.user_service.get_UserList().then(response => {
      this.users = response;
      this.getUsername(this.data);
    })
  }

  getUsername(data) {

    let requests = data.map((item) => {
      return new Promise((resolve) => {
        let foundelemet = this.users.find(x => x.user_id === item.created_by);
        item.name = foundelemet ? foundelemet.username : null;
        this.asyncFunction(item, resolve);
      });
    })

    Promise.all(requests).then(() => {
      this.aDID = data;
      this.DIDDataSource = this.dataSourceBuilder.create(this.aDID.map(item => ({ data: item })),);

    });
  }

  asyncFunction (item, cb) {
    setTimeout(() => {
      // console.log('done with', item);
      cb();
    }, 300);
  }

  deleteDID(account_id): void {
    this.did_service.delete_DID(account_id)
    .then(response => {
    })
    .catch(this.handleError);
    this.getDIDlist();
    this.closeModal();
  }

  // Modal related
  showStaticModal(deleteTemplate,account_id) {
    this.translateService.get('transmission.head').subscribe((translatedTitle: string) => {
      this.windowRef = this.windowService.open(deleteTemplate, { title: translatedTitle, context: { account_id: account_id } });
    });
  }
  closeModal() {
    this.windowRef.close();
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}
