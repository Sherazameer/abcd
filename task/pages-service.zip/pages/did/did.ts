export class DID {
  account_id: number;
  username: string;
  passwd: string;
  passwd_pin: string;
  first_name: string;
  last_name: string;
  phone: any;
  email: string;
  address: string;
  active: number;
  type: any;
  did_number: any;
  title: any;
  assigned_to: any;
  range_from: any;
  range_to: any;
  user_id: any;
  service: any;
  name: any;
  created_by: string; // Assuming 'created_by' is a string property
}
