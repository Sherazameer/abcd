import { Component, OnInit, ViewChild, ElementRef, TemplateRef } from '@angular/core';
import { ExtensionService } from './extension.service';
import { MatSort,  Sort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { ExtensionDatabase } from './extension-database.component';
import { ExtensionDataSource } from './extension-datasource.component';
import { ModalComponent } from '../../modal.component';
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs/Rx';
import { NbWindowService } from '@nebular/theme';
import { TranslateService } from '@ngx-translate/core';
import { NbWindowRef } from '@nebular/theme';
import { NbTreeGridDataSource, NbTreeGridDataSourceBuilder } from '@nebular/theme';
import { Extension } from './extension';


@Component({
  selector: 'ngx-extension-component',
  templateUrl: './extension-component.html',
  styleUrls: ['./extension-component.scss'],
})

export class FormsExtensionComponent implements OnInit {
  constructor(private extension_service: ExtensionService,
   private dataSourceBuilder: NbTreeGridDataSourceBuilder<Extension>,
  private modalService: NgbModal,
  private windowService : NbWindowService,
  private translateService : TranslateService,
) { }

  aExtension: Extension[];
  ExtensionDataSource: NbTreeGridDataSource<Extension>;


  length: number;
  closeResult: any;
  private windowRef: NbWindowRef;
  private modalRef: NgbModalRef;

  displayedColumns= ['ID', 'username', 'phone',  'Operations'];

  @ViewChild(MatSort) sort: MatSort;

  @ViewChild(MatPaginator) paginator: MatPaginator;

  @ViewChild('filter') filter: ElementRef;

  @ViewChild('deleteTemplate', { static: true }) deleteTemplate: TemplateRef<any>;


  ngOnInit() {
    this.getExtensionlist();
  }

  getExtensionlist() {
    this.extension_service.get_ExtensionList().then(data => {
      this.length = data.length;
      this.ExtensionDataSource = this. dataSourceBuilder.create( this. aExtension.map(item => ({ data: item})),);

      // Observable for the filter
      Observable.fromEvent(this.filter.nativeElement, 'keyup')
     .debounceTime(150)
     .distinctUntilChanged()
     .subscribe(() => {
       if (!this.aExtension) { return; }
       this.aExtension.filter = this.filter.nativeElement.value;
      });

      //Sort the data automatically

      const sortState: Sort = {active: 'ID', direction: 'desc'};
      this.sort.active = sortState.active;
      this.sort.direction = sortState.direction;
      this.sort.sortChange.emit(sortState);
    });
  }


  deleteExtension(account_id): void {
    this.extension_service.delete_Extension(account_id)
    .then(response => {
    })
    .catch(this.handleError);
    this.getExtensionlist();
    this.closeModal();
  }

  // Modal related
  showStaticModal(account_id, first_name) {
    this.translateService.get('transmission.head').subscribe((translatedTitle: string) => {
      this.windowRef = this.windowService.open(this.deleteTemplate, { title: translatedTitle, context: { first_name: first_name, account_id: account_id } });
    });
  }
  closeModal() {
    this.windowRef.close();
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}
