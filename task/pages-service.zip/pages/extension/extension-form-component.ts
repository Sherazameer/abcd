import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { User } from '../user/user';
import { AUserService } from '../user/user.service';
import { Extension, Settings } from './extension';
import { ExtensionService } from './extension.service';
import 'rxjs/add/operator/toPromise';
import { toInteger } from '@ng-bootstrap/ng-bootstrap/util/util';


@Component({
  selector: 'ngx-add-extension-component',
  templateUrl: './extension-form-component.html',
  styleUrls: ['./extension-form-component.scss'],
})


export class AddExtensionComponent implements OnInit {

  constructor(private route: ActivatedRoute, private account_service: ExtensionService,
  private router: Router, private user_service: AUserService) { }

  // form1: any= {};
  extension: Extension= new Extension;
  account_id: any= null;
  form: FormGroup;

  settings: Settings = new Settings;
  public sendbody: any = false;
  public sendcover: any = false;

  isError = false;
  errorText: any = [];
  user: User[] = [];
  selectedUser: User;

  ngOnInit(): void {
    this.getUserList();
    this.route.params.subscribe(params => {
      this.account_id = +params['id'];
      const test_url = this.router.url.split('/');
      const lastsegment = test_url[test_url.length - 1];
      if (lastsegment === 'new') {
        return null;
      } else {
        return this.account_service.get_ExtensionData(this.account_id).then(data => {
          this.extension = data;
        });
      }
    });
  }

  getUserList() {
    this.user_service.get_UserList().then(data => {
      this.user = data;
    });
  }

  get selectedUsr() {
    return this.selectedUser;
  }

  set selectedUsr(value) {
    this.selectedUser = value;
    this.extension.user_id = this.selectedUser.user_id;
  }

  addExtension(): void {   
    this.checkFields();
    if (this.errorText.length === 0) {
      this.extension.type = 'extension';
      this.account_service.add_Extension(this.extension).then(response => {
        this.extension.account_id = response;
        // Assign extension to selected user
        // if (this.extension.user_id) {
        //   this.account_service.assign_Extension(this.extension);
        // }
        this.router.navigate(['../../extension'], {relativeTo: this.route});
      });
    }else{
      this.errorHandler(true, this.errorText);
      }
  }

  updateExtension(): void {
    this.checkFields();
    if (this.errorText.length === 0) {
      this.account_service.update_Extension(this.extension).then(response => {
        this.extension.account_id = this.account_id;
        // Assign extension to selected user
        // if (this.extension.user_id) {
        //   this.account_service.assign_Extension(this.extension);
        // }
        this.router.navigate(['../../extension'], {relativeTo: this.route});
      })
      .catch(this.handleError);
    }else{
      this.errorHandler(true, this.errorText);
    }
  }

  private checkFields(status = null):any{
    this.errorHandler(false, [])
    if (!this.extension.username) this.errorText.push("Username is required.");
    if (!this.extension.passwd) this.errorText.push("Password is required.");
    if (!this.extension.phone) this.errorText.push("Phone is required.");
  }

  private errorHandler(status, message):any{
    this.isError = status;
    this.errorText = message;
    if (status) {
      setTimeout(() => {
        this.isError = false;
        this.errorText = [];
      }, 10000);
    }
  }
  
  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}
